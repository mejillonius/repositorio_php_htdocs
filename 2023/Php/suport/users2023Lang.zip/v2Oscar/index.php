<?php

// Des d'aquí cridem al fitxer app.php que és que ens fa de controller i carrega les diferents parts de la pàgina
header("Location:controller/app.php");