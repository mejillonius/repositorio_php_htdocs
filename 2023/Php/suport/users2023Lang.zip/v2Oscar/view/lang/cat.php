<?php

$lang_form=[
	"title" => "Formulari de Registre",
	"usuari" => "Usuari",
	"mail" => "Adreça de Correu Electrònic",
	"registra"=> "Registra't",
	"error_nom"=>"El teu nom d'usuari ha de tenir una longitud d'entre 2 i 40 caràcters. Pot contenir lletres, números i . _ ",
	"error_mail"=>"El teu correu electrònic ha de tenir nom @ domini i una extensió de domini després d'un punt .",
	"missatge_error" => "Hi ha un error en el nom d'usuari/correu electrònic introduït"
];

$lang_feedback=[
	"title" => "Confirmació del Registre",
	"usuari" => "Usuari",
	"mail" => "Adreça de Correu Electrònic",
	"registre_1" => "Gràcies per Registrar-se. Disposa de l'usuari : ",
	"registre_2" => "Rebrà un correu de confirmació a la següent adreça electrònica:",
	"tabla"=> "Aquests són els usuaris registrats fins ara:",
	"tornar"=> "Tornar"
	
];