<?php

$lang_form=[
	"title" => "Formulario de Registro",
	"usuari" => "Usuario",
	"mail" => "Dirección de Correo Electrónico",
	"registra"=> "Regístrate",
	"error_nom"=>"Tu nombre de usuario tiene que tener una longitud de entre 2 y 40 carácteres.Puede contener letras, números y . _ ",
	"error_mail"=>"Tu correo electrónico tiene que contener nombre @ dominio y una extensión de dominio detrás de un punto .",
	"missatge_error" => "Hay un error en el usuario/correo electrónico introducido"
];

$lang_feedback=[
	"title" => "Confirmación del Registro",
	"usuari" => "Usuario",
	"mail" => "Dirección de Correo Electrónico",
	"registre_1" => "Gracias por su registro. Dispone del usuario : ",
	"registre_2" => "Recibirá un correo en la siguiente dirección de correo :",
	"tabla"=> "Estos son los usuarios registrados hasta ahora:",
	"tornar"=> "Volver"
];