<!doctype html>
<html lang="es">
  <head>
    <title>Ejercicios Php básicos</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.0.2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
     <style>

       code{
             display:grid;
             border:1px solid black;
             padding:10px;
             margin: 0 10px;
             background-color: #ccc;
             color:blue;
             }
 </style>

  </head>
  <body>
<div class="container-fluid p-5">
 <h1><strong>Ejercicios básicos de Php</strong></h1>
<p class="pt-3 mx-3"><strong>Ejercicio 1.</strong> <br/>Crear dos variables "país" y "continente" y mostrar su valor por pantalla(imprimir)
mostrar el tipo de dato contienen con alguna función que nos permita obtenerlo.</p>
     <div >
            <code>
&lt;?php <br/>
$pais       = "Cumbatilonia"; // string<br/>
$continente = "Eurofistan"; // string<br/>
echo 'La variable $pais =' . $pais . ' es de tipo ' . gettype($pais) . '&lt;br>';<br/>
echo 'La variable $continente =' . $continente . ' es de tipo ' . gettype($continente) . '&lt;br>';<br/>
var_dump($pais, $continente);<br/>
echo '&lt;h2>' . $pais . ' - ' . $continente . '&lt;/h2>';<br/>
?>
<hr/>
 <?php
$pais = "Cumbatilonia"; // string
$continente = "Eurofistan"; // string
echo 'La variable $pais =' . $pais . ' es de tipo ' . gettype($pais) . '<br>';
echo 'La variable $continente =' . $continente . ' es de tipo ' . gettype($continente) . '<br>';
var_dump($pais, $continente);
echo '<h2>' . $pais . ' - ' . $continente . '</h2>';
?>
</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 2.</strong> <br/>
Ejercicio 2. Escribir un script en PHP que nos muestre por pantalla todos los numeros pares que hay del 1 al 50. (bucle...)</p>
<div >
<code>
&lt;?php<br/>
$contador = 0;<br/>
while ($contador <= 50) {<br/>
 if ($contador % 2 == 0) {<br/>
  echo "&lt;strong>$contador</strong>";<br/>
  if (100 != $contador) {<br/>
   echo ","; }<br/>
 }<br/>
 $contador++;<br/>
}<br/>
?>
<hr />
&lt;?php
for ($i = 0; $i <= 50; $i++) {<br/>

 if ($i % 2 == 0) {<br/>
  echo $i;<br/>
  if (100 != $i) {<br/>
   echo ",";}<br/>
 }<br/>
}<br/>
?>
<hr />
<?php
$contador = 0;
while ($contador <= 50) {
    if ($contador % 2 == 0) {
        echo "$contador";
        if (50 != $contador) {
            echo ", ";
        }
    }
    $contador++;
}
echo "<hr />";

for ($i = 0; $i <= 50; $i++) {

    if ($i % 2 == 0) {
        echo $i;
        if (50 != $i) {
            echo ", ";
        }
    }
}
?>
</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 3.</strong> <br/>
Ejercicio 3. Escribir un programa que imprima por pantalla los cuadrados
(un número multiplicado por sí mismo) de los 10 primeros números naturales.
PD: Utilizar bucle while y el bulce for
</p>
<div >
<code>
&lt;?php<br/>
$cuadrado = 0;<br/>
$contador = 0;<br/>
while ($contador <= 10) {<br/>
 echo $cuadrado = $contador * $contador."&lt;br/>";<br/>
 if (10 != $contador) {<br/>
  echo ",";<br/>
 }
 echo "El cuadrado de $contador es $cuadrado";<br/>
 $contador++;<br/>
};
?>
<hr />
&lt;?php<br/>
for ($contador = 0; $contador <= 10; $contador++) {<br/>
 $cuadrado = $contador * $contador;<br/>
 echo "El cuadrado de $contador es $cuadrado";<br/>
}
?>
<hr />
<?php
$cuadrado = 0;
$contador = 0;
while ($contador <= 10) {
    $cuadrado = $contador * $contador;
    echo "El cuadrado de $contador es $cuadrado";
    if (10 != $contador) {
        echo ". ";
    }
    $contador++;
}
;
echo "<hr />";

for ($contador = 0; $contador <= 10; $contador++) {
    $cuadrado = $contador * $contador;
    echo "El cuadrado de $contador es $cuadrado";
    if (10 != $contador) {
        echo ". ";
    }
}
;
?>
</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 4.</strong> <br/>
Recoger dos numeros por url(Parametros GET) y hacer todas las operaciones basicas de una calculadora(suma, resta, multiplicación y división) de esos dos números, mostrando los números recibidos y el resultado de cada operación en una línea diferente. Si no recibimos ningún parámetro, o contienen errores, usaremos una cabecera que permita no salir del formulario y volver a introducir los datos.</p>
<div id="ejercicio4">
<code><br/>
      &lt;form action="ejercicio4.php" method="GET"><br/>
            &lt;label for="num1">Número 1:&lt;/label><br/>
            &lt;input type="text" name="num1" /><br/>
            &lt;label for="num2">Número 2:&lt;/label><br/>
            &lt;input type="text" name="num2" /><br/>
            &lt;input type="submit" value="Calcular" /><br/>
      &lt;/form><br/>
<hr />
      <form action="ejercicio4.php" method="GET">
            <label for="num1">Número 1:</label>
            <input type="text" name="num1" />
            <label for="num2">Número 2:</label>
            <input type="text" name="num2" />
            <input type="submit" value="Calcular" />
      </form>
<br/>

</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 5.</strong> <br/>
Hacer un programa que muestre todos los números entre dos números que nos lleguen por URL($_GET). El primer número ha de ser menor que el segundo, si no es así informaremos al usuario y el programa volverá al formulario para poder introducir los números. Una vez finalizado el script, este nos ha de permitir volver l formulario para jugar de nuevo.</p>
<div id="ejercicio5">
<code>
      &lt;form action="ejercicio5.php" method="GET"><br/>
            &lt;label for="numero1">Número 1:&lt;/label><br/>
            &lt;input type="text" name="numero1" /><br/>
            &lt;label for="numero2">Número 2:&lt;/label><br/>
            &lt;input type="text" name="numero2" /><br/>
            &lt;input type="submit" value="Calcular" /><br/>
      &lt;/form><br/>
      <hr />
      <form action="ejercicio5.php" method="GET">
            <label for="numero1">Número 1:</label>
            <input type="text" name="numero1" />
            <label for="numero2">Número 2:</label>
            <input type="text" name="numero2" />
            <input type="submit" value="Calcular" />
      </form>
<br/>
</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 6.</strong> <br/>
Mostrar una "table" de HTML con las tablas de multiplicar del 1 al 10.</p>
<div>
<code>
&lt;?php<br/>
$tabla = "&lt;table class='table table-responsive table-warning border-secondary w-auto text-center'> &lt;tr>"; // inicio de la tabla<br/>
// inicio fila 1 de celdas<br/>
for ($cabecera = 1; $cabecera &lt;= 10; $cabecera++) {<br/>
    $tabla .= "&lt;th class='mx-0 px-0'>Tabla del $cabecera&lt;/th>";<br/>
}<br/>
//filas y celdas<br/>
$tabla .= "&lt;/tr>&lt;tr>"; // inicio fila 2 de celdas<br/>
for ($i = 1; $i &lt;= 10; $i++) {<br/>
    $tabla .= "&lt;td  class='mx-0 px-0'>";<br/>
    //rellenamos celdas<br/>
    for ($x = 1; $x &lt;= 10; $x++) {<br/>
        $tabla .= "$i x $x = " . ($i * $x) . "&lt;br>";<br/>
    }<br/>
    $tabla .= "&lt;/td>";<br/>
}<br/>
$tabla .= "&lt;/tr>&lt;/table>"; // fin de la tabla<br/>
echo $tabla;<br/>
?><br/>
<hr/>
<?php
$tabla = "<table class='table table-responsive table-warning border-secondary w-auto text-center'> <tr>"; // inicio de la tabla
// inicio fila 1 de celdas
for ($cabecera = 1; $cabecera <= 10; $cabecera++) {
    $tabla .= "<th class='mx-0 px-0'>Tabla-$cabecera</th>";
}
//filas y celdas
$tabla .= "</tr><tr>"; // inicio fila 2 de celdas
for ($i = 1; $i <= 10; $i++) {
    $tabla .= "<td class='mx-0 px-0'>";
    //rellenamos celdas
    for ($x = 1; $x <= 10; $x++) {
        $tabla .= $i . "x" . $x . "=" . ($i * $x) . "<br>";
    }
    $tabla .= "</td>";
}
$tabla .= "</tr></table>"; // fin de la tabla
echo $tabla;
?>

</code>
</div>
<p class="pt-4 mx-3"><strong>Ejercicio 7.</strong> <br/>
 Hacer un programa que muestre todos los números (indicando en cada número si es par o impar) entre dos números que nos lleguen por URL($_GET) de un formulario. El primer número ha de ser menor que el segundo, si no es así informaremos al usuario y permitiremos con un input de tipo button que vuelva al formulario volveremos a introducir los números. Una vez finalizado el script, este nos ha de permitir volver al formulario para jugar de nuevo.
</p>
<div class="ejercicio7">
<code>
       &lt;form action="ejercicio7.php" method="GET"><br/>
            &lt;label for="number1">Número 1:&lt;/label><br/>
            &lt;input type="text" name="number1" /><br/>
            &lt;label for="number2">Número 2:&lt;/label><br/>
            &lt;input type="text" name="number2" /><br/>
            &lt;input type="submit" value="Calcular" /><br/>
      &lt;/form><br/>
      <hr />
       <form action="ejercicio7.php" method="GET">
            <label for="number1">Número 1:</label>
            <input type="text" name="number1" />
            <label for="number2">Número 2:</label>
            <input type="text" name="number2" />
            <input type="submit" value="Calcular" />
      </form>
      <br/>
</code>
</div>
 </body>
</html>