<!doctype html>
<html lang="es">

<head>
      <title>Ejercicios Php básicos</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.0.2 -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <style>
      code {
            display: grid;
            border: 1px solid black;
            padding: 10px;
            margin: 0 10px;
            background-color: #ccc;
            color: blue;
      }
      </style>

</head>

<body>
      <div class="container-fluid p-5">
            <h1><strong>Resolución ejercicio 4 </strong></h1>
            <h3><strong>Accedemos desde ejercicios1-7_def.php "Ejercicio 4"</strong></h3>
            <div>
                  <code>
&lt;?php<br/>

if (isset($_GET['num1']) && isset($_GET['num2'])) {<br/>

    $numero1 = $_GET['num1'];<br/>
    $numero2 = $_GET['num2'];<br/>
    if (is_numeric($numero1) && is_numeric($numero2)) {<br/>

        echo "&lt;h1>Calculadora&lt;/h1>";<br/>
        echo "Suma: " . ($numero1 + $numero2) . " &lt;br/>";<br/>
        echo "Resta: " . ($numero1 - $numero2) . " &lt;br/>";<br/>
        echo "Multiplicación: " . ($numero1 * $numero2) . " &lt;br/>";<br/>
        echo "División: " . ($numero1 / $numero2);<br/>
        header("Refresh: 10; url=ejercicios1-7_def.php#ejercicio4");<br/>

    } else {<br/>
        header("Location: ejercicios1-7_def.php#ejercicio4");<br/>

    }<br/>
}<br/>
?><br/>
<hr/>
<?php
if (isset($_GET['num1']) && isset($_GET['num2'])) {

    $numero1 = $_GET['num1'];
    $numero2 = $_GET['num2'];
    if (is_numeric($numero1) && is_numeric($numero2)) {

        echo "<h1>Calculadora</h1>";
        echo "Suma: " . ($numero1 + $numero2) . " <br/>";
        echo "Resta: " . ($numero1 - $numero2) . " <br/>";
        echo "Multiplicación: " . ($numero1 * $numero2) . " <br/>";
        echo "División: " . ($numero1 / $numero2);
        header("Refresh: 3; url=ejercicios1-7_def.php#ejercicio4");

    } else {
        header("Location: ejercicios1-7_def.php#ejercicio4");

    }
}
?><br/>
       </code>
            </div>
      </div>
</body>

</html>