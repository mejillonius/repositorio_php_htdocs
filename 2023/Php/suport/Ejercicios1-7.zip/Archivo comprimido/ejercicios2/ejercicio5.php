<!doctype html>
<html lang="es">

<head>
      <title>Ejercicios Php básicos</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.0.2 -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <style>
      code {
            display: grid;
            border: 1px solid black;
            padding: 10px;
            margin: 0 10px;
            background-color: #ccc;
            color: blue;
      }
      </style>

</head>

<body>
      <div class="container-fluid p-5">
            <h1><strong>Resolución ejercicio 5 </strong></h1>
            <h3><strong>Accedemos desde ejercicios1-7_def.php "Ejercicio 5"</strong></h3>
            <div>
                  <code>
&lt;?php<br/>
if (isset($_GET['numero1']) && isset($_GET['numero2'])) {<br/>
    $numero1 = $_GET['numero1'];<br/>
    $numero2 = $_GET['numero2'];<br/>

    if (is_numeric($numero1) && is_numeric($numero2)) {<br/>

        if ($numero1 < $numero2) {<br/>
            for ($i = $numero1; $i <= $numero2; $i++) {<br/>
                echo "$i&lt;br/>";<br/>
            }
            echo "&lt;p onclick='history.back();'>Volver a jugar? &lt;/p>";<br/>
        } else {<br/>
            echo "&lt;h4>El numero 1 debe ser menor al numero 2 &lt;/h4>";<br/>
            header('refresh:3;url=ejercicios1-7_def.php#ejercicio5');<br/>
        }<br/>
    } else {<br/>
        echo "&lt;h2>Los parametros get no existen&lt;/h2>";<br/>
        header('refresh:3;url=ejercicios1-7_def.php#ejercicio5');}<br/>
}<br/>
?><br/>
<hr/>
<?php
if (isset($_GET['numero1']) && isset($_GET['numero2'])) {
    $numero1 = $_GET['numero1'];
    $numero2 = $_GET['numero2'];

    if (is_numeric($numero1) && is_numeric($numero2)) {

        if ($numero1 < $numero2) {
            for ($i = $numero1; $i <= $numero2; $i++) {
                echo "$i";
                if ($i != $numero2) {
                    echo ". ";
                }
            }
            echo "<a class='col-4 btn btn-primary' href='javascript:history.back();'>Volver a jugar? </a>";
        } else {
            echo "<h4>El numero 1 debe ser menor al numero 2 </h4>";
            header('refresh:2;url=ejercicios1-7_def.php#ejercicio5');
        }
    } else {
        echo "<h2>Los parametros get no existen</h2>";
        header('refresh:2;url=ejercicios1-7_def.php#ejercicio5');
    }
}
;
?>
        <br/>
       </code>
            </div>
      </div>
</body>

</html>