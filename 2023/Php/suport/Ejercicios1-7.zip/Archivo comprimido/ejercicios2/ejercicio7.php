<!doctype html>
<html lang="es">
  <head>
    <title>Ejercicios Php básicos</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.0.2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"  integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
     <style>

       code{
             display:grid;
             border:1px solid black;
             padding:10px;
             margin: 0 10px;
             background-color: #ccc;
             color:blue;
             }
 </style>

  </head>
  <body>
<div class="container-fluid p-5">
 <h1><strong>Resolución ejercicio 7 </strong></h1>
 <h3><strong>Accedemos desde ejercicios1-7_def.php "Ejercicio 7"</strong></h3>
<div >
       <code>
&lt;?php<br/>
if (isset($_GET['number1']) && isset($_GET['number2'])) {<br/>
    $numero1 = $_GET['number1'];<br/>
    $numero2 = $_GET['number2'];<br/>
    if (!is_numeric($numero1) || !is_numeric($numero2)) {<br/>
        echo "No me engañes&lt;br/>";<br/>
        echo "&lt;input type='button' onclick='history.back();' value='Volver al form?'>";<br/>
    }<br/>
    if ($numero1 < $numero2) {<br/>
        for ($i = $numero1; $i <= $numero2; $i++) {<br/>

            if ($i % 2 != 0) {<br/>
                echo "&lt;p>$i Es IMPAR&lt;/p>";<br/>
            } else {<br/>
                echo "&lt;p>$i Es PAR&lt;/p>";<br/>
            }<br/>
        }<br/>
        echo "&lt;a class='col-4 btn btn-primary' href='javascript:history.back();'>Volver al formulario? &lt;/a>";<br/>
    } else {<br/>
        echo "&lt;h1>El numero 1 debe ser menor al numero 2";<br/>
    }<br/>
} else {<br/>
    echo "&lt;h1>Los parametros get no existen&lt;/h1>";<br/>
    header('refresh:5;url=ejercicios1-7.php#ejercicio7');<br/>
}<br/>
?>
<hr/>
<?php
if (isset($_GET['number1']) && isset($_GET['number2'])) {
    $numero1 = $_GET['number1'];
    $numero2 = $_GET['number2'];
    if (!is_numeric($numero1) || !is_numeric($numero2)) {
        echo "No me engañes<br/>";
        echo "<a class='col-4 btn btn-primary' href='javascript:history.back();'>Volver al formulario? </a>";
    }

    if ($numero1 < $numero2) {
        for ($i = $numero1; $i <= $numero2; $i++) {

            if ($i % 2 != 0) {
                echo "<p>$i Es IMPAR</p>";
            } else {
                echo "<p>$i Es PAR</p>";
            }
        }
        echo "<a class='col-4 btn btn-primary' href='javascript:history.back();'>Volver al formulario? </a>";
    } else {
        echo "<h2>El numero 1 debe ser menor al numero 2</h2>";
    }
} else {
    echo "<h2>Los parametros get no existen</h2>";
    header('refresh:5;url=ejercicios1-7.php#ejercicio7');
}
?>
</code>
</div>
</div>
  </body>
</html>
