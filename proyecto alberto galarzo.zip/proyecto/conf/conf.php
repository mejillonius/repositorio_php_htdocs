<?php

echo(LOADDEBUG?"loader debug conf <br> ":"");
define('url_base', '//' . $_SERVER['SERVER_NAME'] . '/proyecto/');
define('url_controller','./../controller/');
