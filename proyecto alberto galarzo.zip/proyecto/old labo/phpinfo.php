<?php phpinfo() ?>

