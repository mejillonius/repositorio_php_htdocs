<?php
echo(LOADDEBUG?"Debug loader 404 <br> ":"");
?>

<div class="text-center">
      <h1>404</h1>
      <p>Página no encontrada</p>
      <a href="index.php" class="btn btn-primary">Volver</a>
</div>