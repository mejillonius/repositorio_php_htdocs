<?php
echo(LOADDEBUG?"Debug loader inicio <br> ":"");
?>
inicio

barra lateral y contenido demo