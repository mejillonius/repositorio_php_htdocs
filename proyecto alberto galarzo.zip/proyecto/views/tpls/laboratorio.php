<?php
echo(LOADDEBUG?"Debug loader laboratorio <br> ":"");
?>
laboratorio

iframe y comunicacion con el labo