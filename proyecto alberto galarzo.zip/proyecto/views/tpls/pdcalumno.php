<?php
if ($_COOKIE['cookierol'] != 'alumno'){
    header("Refresh:0; url=".url_base);
}
?>

<h1>pdcalumno</h1>

<n2>apuntarse a practica</n2>

<p>revisar practicas apuntadas</p>

<p>entrar a practicas</p>