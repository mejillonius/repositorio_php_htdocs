<?php
define('url_inici', '//' . $_SERVER['SERVER_NAME'] . '/appdist/pelisSinUsers/');
define('url_base', $_SERVER['REQUEST_URI']);
/*echo "<pre><code>";
/* var_dump($_SERVER);
echo "</code></pre>";*/
/* /Applications/XAMPP/xamppfiles/htdocs/2023/appdist/pelisSinUsers/20_pelis/conf/conf.php */

define('url_login', '//' . $_SERVER['SERVER_NAME'] . '/appdist/usersSinPelis/');
