<?php


class MontaTpls
{
	public function montaTpls()
	{
		require_once "views/template.php";
		/* 	require_once "views/tpls/nav.php"; */
	}
}
