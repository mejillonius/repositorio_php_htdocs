<?php
define('url_inici', '//' . $_SERVER['SERVER_NAME'] . '/appdist/usersSinPelis/');
define('url_base', $_SERVER['REQUEST_URI']);
